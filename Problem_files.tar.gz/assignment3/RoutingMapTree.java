public class RoutingMapTree{

	public RoutingMapTree() {
		//
	}

	public void performAction(String actionMessage) {
		System.out.println(actionMessage);	
	}
}
